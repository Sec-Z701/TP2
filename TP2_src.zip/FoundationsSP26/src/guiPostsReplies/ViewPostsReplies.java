package guiPostsReplies;

import java.util.ArrayList;

import entityClasses.Post;
import entityClasses.Reply;
import entityClasses.User;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/*******
 * <p> Title: ViewPostsReplies Class </p>
 *
 * <p> Description: This is the View component of the Model-View-Controller (MVC) pattern for
 * the Student Discussion page.  It provides the JavaFX GUI that allows students to create,
 * read, update, delete, and search posts and replies.</p>
 *
 * <p> The page displays four lists: all posts, a subset of posts (search results), all replies,
 * and a subset of replies (search/filter results).  This satisfies the requirement that the
 * system supports storing all current posts as well as any subset of posts.</p>
 *
 * <p> This class uses the singleton design pattern consistent with the other GUI pages in the
 * application (e.g., ViewAdminHome, ViewRole1Home).  All access starts by calling the static
 * method displayPostsReplies.  The constructor is private so only one instance is created.</p>
 *
 * <p> Copyright: Lynn Robert Carter © 2025 </p>
 *
 * @author Lynn Robert Carter
 *
 * @version 1.00	2025-03-15 Initial standalone version for HW2
 * @version 2.00	2025-03-20 Refactored to singleton for TP2 integration
 */
public class ViewPostsReplies {

	// Post input widgets - used by the Controller to read user input for post CRUD operations
	protected static TextField tfPostId = new TextField();
	protected static TextField tfPostAuthor = new TextField();
	protected static TextField tfPostThread = new TextField();
	protected static TextField tfPostTitle = new TextField();
	protected static TextArea  taPostBody = new TextArea();
	protected static TextField tfPostSearch = new TextField();
	protected static CheckBox  cbConfirmDelete = new CheckBox("Confirm delete (Are you sure?)");

	// Post list displays - allPosts shows every post, subsetPosts shows search results
	protected static ListView<String> lvAllPosts = new ListView<>();
	protected static ListView<String> lvSubsetPosts = new ListView<>();

	// Reply input widgets - used by the Controller to read user input for reply CRUD operations
	protected static TextField tfReplyId = new TextField();
	protected static TextField tfReplyPostId = new TextField();
	protected static TextField tfReplyAuthor = new TextField();
	protected static TextArea  taReplyBody = new TextArea();
	protected static TextField tfReplySearch = new TextField();

	// Reply list displays - allReplies shows every reply, subsetReplies shows search/filter results
	protected static ListView<String> lvAllReplies = new ListView<>();
	protected static ListView<String> lvSubsetReplies = new ListView<>();

	// Status message label - shows success or error messages after each operation
	protected static Label lblMessage = new Label("");

	// Singleton and shared references - same pattern as ViewAdminHome
	private static ViewPostsReplies theView;	// Used to check if we need to create it
	protected static Stage theStage;			// The Stage that JavaFX has established
	protected static User theUser;				// The current logged in User
	private static Scene theScene;				// The shared Scene each time we display


	/**********
	 * <p> Method: displayPostsReplies(Stage ps, User user) </p>
	 *
	 * <p> Description: This is the single entry point from outside this package to show the
	 * Student Discussion page.  It follows the same pattern as displayAdminHome and
	 * displayRole1Home: set up shared references, create the singleton if needed, populate
	 * the dynamic fields, and show the scene.</p>
	 *
	 * @param ps	the JavaFX Stage to display on
	 * @param user	the currently logged-in User
	 */
	public static void displayPostsReplies(Stage ps, User user) {

		// Save references so other classes in this package can use them
		theStage = ps;
		theUser = user;

		// Create the GUI the first time, reuse it after that
		if (theView == null) theView = new ViewPostsReplies();

		// Set the author fields to the logged-in user's name each time we display.
		// This way the student does not have to type their own username.
		tfPostAuthor.setText(theUser.getUserName());
		tfReplyAuthor.setText(theUser.getUserName());

		// Refresh the lists to show any existing posts/replies
		ControllerPostsReplies.refreshLists();

		// Clear old status messages
		lblMessage.setText("");

		// Show the page
		theStage.setTitle("CSE 360 Foundations: Student Discussion");
		theStage.setScene(theScene);
		theStage.show();
	}

	/**********
	 * <p> Method: ViewPostsReplies() </p>
	 *
	 * <p> Description: Private constructor that builds the GUI.  Only called once because
	 * this is a singleton.  The layout uses VBox and HBox to place the post panel and
	 * reply panel side by side, with navigation buttons at the bottom.</p>
	 */
	private ViewPostsReplies() {

		VBox root = new VBox(12);
		root.setPadding(new Insets(12));

		lblMessage.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

		// Post and Reply panels are placed side by side
		HBox top = new HBox(12,
				buildPostPane(),
				buildReplyPane()
		);

		// Navigation buttons - same as other pages (Return, Logout, Quit)
		Button btnReturn = new Button("Return to Home");
		btnReturn.setOnAction(e -> ControllerPostsReplies.performReturn());

		Button btnLogout = new Button("Logout");
		btnLogout.setOnAction(e -> ControllerPostsReplies.performLogout());

		Button btnQuit = new Button("Quit");
		btnQuit.setOnAction(e -> ControllerPostsReplies.performQuit());

		HBox navButtons = new HBox(12, btnReturn, btnLogout, btnQuit);

		root.getChildren().addAll(
				new Label("Student Discussion"),
				top,
				new Separator(),
				new Label("Messages / Errors:"),
				lblMessage,
				new Separator(),
				navButtons
		);

		theScene = new Scene(root, 1100, 700);
	}

	// -------------------------
	// UI Sections
	// -------------------------

	/**********
	 * <p> Method: buildPostPane() </p>
	 *
	 * <p> Description: Builds the left-side panel containing post input fields, CRUD buttons,
	 * and post list displays.  Called once by the constructor.</p>
	 *
	 * @return a Pane containing all the post-related widgets
	 */
	private Pane buildPostPane() {

		tfPostId.setPromptText("PostId (for update/delete)");
		tfPostAuthor.setPromptText("Author username");
		tfPostThread.setPromptText("Thread (optional)");
		tfPostTitle.setPromptText("Title");
		taPostBody.setPromptText("Body");
		taPostBody.setPrefRowCount(4);

		tfPostSearch.setPromptText("Search keyword");

		// Button handlers call the static Controller methods
		Button btnCreate = new Button("Create Post");
		btnCreate.setOnAction(e -> ControllerPostsReplies.handleCreatePost());

		Button btnUpdate = new Button("Update Post");
		btnUpdate.setOnAction(e -> ControllerPostsReplies.handleUpdatePost());

		Button btnDelete = new Button("Delete Post");
		btnDelete.setOnAction(e -> ControllerPostsReplies.handleDeletePost());

		Button btnSearch = new Button("Search Posts");
		btnSearch.setOnAction(e -> ControllerPostsReplies.handleSearchPosts());

		Button btnClearSubset = new Button("Clear Post Subset");
		btnClearSubset.setOnAction(e -> ControllerPostsReplies.handleClearPostSubset());

		VBox inputs = new VBox(6,
				new Label("POST INPUTS"),
				tfPostId,
				tfPostAuthor,
				tfPostThread,
				tfPostTitle,
				taPostBody,
				cbConfirmDelete,
				new HBox(6, btnCreate, btnUpdate, btnDelete),
				new Separator(),
				new Label("POST SEARCH (subsetPosts)"),
				tfPostSearch,
				new HBox(6, btnSearch, btnClearSubset)
		);

		VBox lists = new VBox(6,
				new Label("All Posts (allPosts)"),
				lvAllPosts,
				new Label("Subset Posts (subsetPosts)"),
				lvSubsetPosts
		);

		lvAllPosts.setPrefHeight(220);
		lvSubsetPosts.setPrefHeight(220);

		HBox pane = new HBox(12, inputs, lists);
		pane.setPadding(new Insets(8));
		pane.setStyle("-fx-border-color: gray; -fx-border-width: 1px;");

		return pane;
	}

	/**********
	 * <p> Method: buildReplyPane() </p>
	 *
	 * <p> Description: Builds the right-side panel containing reply input fields, CRUD buttons,
	 * and reply list displays.  Called once by the constructor.</p>
	 *
	 * @return a Pane containing all the reply-related widgets
	 */
	private Pane buildReplyPane() {

		tfReplyId.setPromptText("ReplyId (for update/delete)");
		tfReplyPostId.setPromptText("PostId (reply belongs to this post)");
		tfReplyAuthor.setPromptText("Author username");
		taReplyBody.setPromptText("Reply body");
		taReplyBody.setPrefRowCount(4);

		tfReplySearch.setPromptText("Search keyword");

		// Button handlers call the static Controller methods
		Button btnCreate = new Button("Create Reply");
		btnCreate.setOnAction(e -> ControllerPostsReplies.handleCreateReply());

		Button btnUpdate = new Button("Update Reply");
		btnUpdate.setOnAction(e -> ControllerPostsReplies.handleUpdateReply());

		Button btnDelete = new Button("Delete Reply");
		btnDelete.setOnAction(e -> ControllerPostsReplies.handleDeleteReply());

		Button btnSearch = new Button("Search Replies");
		btnSearch.setOnAction(e -> ControllerPostsReplies.handleSearchReplies());

		Button btnFilterByPost = new Button("Filter by PostId");
		btnFilterByPost.setOnAction(e -> ControllerPostsReplies.handleFilterRepliesByPostId());

		Button btnClearSubset = new Button("Clear Reply Subset");
		btnClearSubset.setOnAction(e -> ControllerPostsReplies.handleClearReplySubset());

		VBox inputs = new VBox(6,
				new Label("REPLY INPUTS"),
				tfReplyId,
				tfReplyPostId,
				tfReplyAuthor,
				taReplyBody,
				new HBox(6, btnCreate, btnUpdate, btnDelete),
				new Separator(),
				new Label("REPLY SEARCH/FILTER (subsetReplies)"),
				tfReplySearch,
				new HBox(6, btnSearch, btnFilterByPost, btnClearSubset)
		);

		VBox lists = new VBox(6,
				new Label("All Replies (allReplies)"),
				lvAllReplies,
				new Label("Subset Replies (subsetReplies)"),
				lvSubsetReplies
		);

		lvAllReplies.setPrefHeight(220);
		lvSubsetReplies.setPrefHeight(220);

		HBox pane = new HBox(12, inputs, lists);
		pane.setPadding(new Insets(8));
		pane.setStyle("-fx-border-color: gray; -fx-border-width: 1px;");

		return pane;
	}

	// -------------------------
	// Getters for Controller
	// -------------------------

	// These getters let the Controller read the input field values without accessing the
	// widget objects directly.

	protected static Integer getPostId() { return parseIntOrNull(tfPostId.getText()); }
	protected static String getPostAuthor() { return tfPostAuthor.getText(); }
	protected static String getPostThread() { return tfPostThread.getText(); }
	protected static String getPostTitle() { return tfPostTitle.getText(); }
	protected static String getPostBody() { return taPostBody.getText(); }
	protected static String getPostSearchKeyword() { return tfPostSearch.getText(); }
	protected static boolean getDeleteConfirm() { return cbConfirmDelete.isSelected(); }

	protected static Integer getReplyId() { return parseIntOrNull(tfReplyId.getText()); }
	protected static Integer getReplyPostId() { return parseIntOrNull(tfReplyPostId.getText()); }
	protected static String getReplyAuthor() { return tfReplyAuthor.getText(); }
	protected static String getReplyBody() { return taReplyBody.getText(); }
	protected static String getReplySearchKeyword() { return tfReplySearch.getText(); }

	/**********
	 * <p> Method: parseIntOrNull(String s) </p>
	 *
	 * <p> Description: Tries to parse a String into an Integer.  Returns null if the string
	 * is null, empty, or not a number.  This avoids crashes when the user types something
	 * that is not a number into an ID field.</p>
	 *
	 * @param s		the string to parse
	 *
	 * @return the Integer value, or null if parsing fails
	 */
	private static Integer parseIntOrNull(String s) {
		try {
			if (s == null) return null;
			String t = s.trim();
			if (t.isEmpty()) return null;
			return Integer.parseInt(t);
		} catch (Exception ex) {
			return null;
		}
	}

	// -------------------------
	// Setters for list updates
	// -------------------------

	// These setters let the Controller update the View's display after each operation.

	/** Sets the status message label text. */
	protected static void setMessage(String msg) {
		lblMessage.setText(msg);
	}

	/** Updates the All Posts ListView with the given list. */
	protected static void setAllPosts(ArrayList<Post> posts) {
		lvAllPosts.getItems().clear();
		for (Post p : posts) lvAllPosts.getItems().add(p.toString());
	}

	/** Updates the Subset Posts ListView with the given list. */
	protected static void setSubsetPosts(ArrayList<Post> posts) {
		lvSubsetPosts.getItems().clear();
		for (Post p : posts) lvSubsetPosts.getItems().add(p.toString());
	}

	/** Updates the All Replies ListView with the given list. */
	protected static void setAllReplies(ArrayList<Reply> replies) {
		lvAllReplies.getItems().clear();
		for (Reply r : replies) lvAllReplies.getItems().add(r.toString());
	}

	/** Updates the Subset Replies ListView with the given list. */
	protected static void setSubsetReplies(ArrayList<Reply> replies) {
		lvSubsetReplies.getItems().clear();
		for (Reply r : replies) lvSubsetReplies.getItems().add(r.toString());
	}
}