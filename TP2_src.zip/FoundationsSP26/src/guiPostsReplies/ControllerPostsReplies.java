package guiPostsReplies;

/*******
 * <p> Title: ControllerPostsReplies Class </p>
 *
 * <p> Description: This is the Controller component of the Model-View-Controller (MVC) pattern
 * for the Student Discussion page.  It reads user input from the View, calls the appropriate
 * operation on the Model, and updates the View to show the result.</p>
 *
 * <p> This controller is not instantiated.  It is a collection of protected static methods
 * that can be called by the View, consistent with ControllerAdminHome and ControllerRole1Home.
 * Each handler follows the same flow: read input from View, call Model, show result, refresh
 * the list displays.</p>
 *
 * <p> Copyright: Lynn Robert Carter © 2025 </p>
 *
 * @author Lynn Robert Carter
 *
 * @version 1.00	2025-03-15 Initial version for HW2
 * @version 2.00	2025-03-20 Refactored to static methods for TP2 integration
 */
public class ControllerPostsReplies {

	// Static reference to the singleton Model
	private static ModelPostsReplies model = ModelPostsReplies.getInstance();

	/**
	 * Default constructor is not used.
	 */
	public ControllerPostsReplies() {
	}

	// -----------------------
	// POST handlers
	// -----------------------

	/**********
	 * <p> Method: handleCreatePost() </p>
	 *
	 * <p> Description: Handles the "Create Post" button.  Reads the author, thread, title,
	 * and body from the View and asks the Model to create the post.  Shows a success or
	 * error message depending on the result.</p>
	 */
	protected static void handleCreatePost() {
		// Read input values from the View's fields
		String err = model.createPost(
				ViewPostsReplies.getPostAuthor(),
				ViewPostsReplies.getPostThread(),
				ViewPostsReplies.getPostTitle(),
				ViewPostsReplies.getPostBody()
		);

		// Show the result to the user
		if (err.isEmpty()) ViewPostsReplies.setMessage("Post created.");
		else ViewPostsReplies.setMessage(err);

		refreshLists();
	}

	/**********
	 * <p> Method: handleUpdatePost() </p>
	 *
	 * <p> Description: Handles the "Update Post" button.  Requires a valid PostId to
	 * identify which post to update.  All fields are re-validated before the update.</p>
	 */
	protected static void handleUpdatePost() {
		// PostId must be a valid integer so we know which post to update
		Integer postId = ViewPostsReplies.getPostId();
		if (postId == null) {
			ViewPostsReplies.setMessage("PostId must be a valid integer.");
			return;
		}

		String err = model.updatePost(
				postId,
				ViewPostsReplies.getPostAuthor(),
				ViewPostsReplies.getPostThread(),
				ViewPostsReplies.getPostTitle(),
				ViewPostsReplies.getPostBody()
		);

		if (err.isEmpty()) ViewPostsReplies.setMessage("Post updated.");
		else ViewPostsReplies.setMessage(err);

		refreshLists();
	}

	/**********
	 * <p> Method: handleDeletePost() </p>
	 *
	 * <p> Description: Handles the "Delete Post" button.  Requires a valid PostId and the
	 * confirm checkbox to be selected.  The two-step confirmation prevents accidental
	 * deletion.</p>
	 */
	protected static void handleDeletePost() {
		Integer postId = ViewPostsReplies.getPostId();
		if (postId == null) {
			ViewPostsReplies.setMessage("PostId must be a valid integer.");
			return;
		}

		// The checkbox acts as a safety step so users don't accidentally delete a post
		boolean confirm = ViewPostsReplies.getDeleteConfirm();

		String err = model.deletePost(postId, confirm);
		if (err.isEmpty()) ViewPostsReplies.setMessage("Post deleted.");
		else ViewPostsReplies.setMessage(err);

		refreshLists();
	}

	/**********
	 * <p> Method: handleSearchPosts() </p>
	 *
	 * <p> Description: Handles the "Search Posts" button.  Searches all posts for the
	 * keyword and puts the results in the subset list.</p>
	 */
	protected static void handleSearchPosts() {
		String err = model.searchPosts(ViewPostsReplies.getPostSearchKeyword());
		if (err.isEmpty()) {
			ViewPostsReplies.setMessage("Post search completed.");
		} else {
			ViewPostsReplies.setMessage(err);
		}
		refreshLists();
	}

	/**********
	 * <p> Method: handleClearPostSubset() </p>
	 *
	 * <p> Description: Handles the "Clear Post Subset" button.  Clears the search results
	 * so the subset list goes back to being empty.</p>
	 */
	protected static void handleClearPostSubset() {
		model.clearPostSubset();
		ViewPostsReplies.setMessage("Post subset cleared.");
		refreshLists();
	}

	// -----------------------
	// REPLY handlers
	// -----------------------

	/**********
	 * <p> Method: handleCreateReply() </p>
	 *
	 * <p> Description: Handles the "Create Reply" button.  Requires a valid PostId so the
	 * reply can be linked to its parent post.  The Model checks that the parent post exists
	 * before allowing creation.</p>
	 */
	protected static void handleCreateReply() {
		// PostId is required so the reply knows which post it belongs to
		Integer postId = ViewPostsReplies.getReplyPostId();
		if (postId == null) {
			ViewPostsReplies.setMessage("Reply postId must be a valid integer.");
			return;
		}

		String err = model.createReply(postId, ViewPostsReplies.getReplyAuthor(), ViewPostsReplies.getReplyBody());
		if (err.isEmpty()) ViewPostsReplies.setMessage("Reply created.");
		else ViewPostsReplies.setMessage(err);

		refreshLists();
	}

	/**********
	 * <p> Method: handleUpdateReply() </p>
	 *
	 * <p> Description: Handles the "Update Reply" button.  Requires a valid ReplyId to
	 * identify which reply to update.</p>
	 */
	protected static void handleUpdateReply() {
		Integer replyId = ViewPostsReplies.getReplyId();
		if (replyId == null) {
			ViewPostsReplies.setMessage("ReplyId must be a valid integer.");
			return;
		}

		String err = model.updateReply(replyId, ViewPostsReplies.getReplyAuthor(), ViewPostsReplies.getReplyBody());
		if (err.isEmpty()) ViewPostsReplies.setMessage("Reply updated.");
		else ViewPostsReplies.setMessage(err);

		refreshLists();
	}

	/**********
	 * <p> Method: handleDeleteReply() </p>
	 *
	 * <p> Description: Handles the "Delete Reply" button.  Requires a valid ReplyId to
	 * identify which reply to delete.</p>
	 */
	protected static void handleDeleteReply() {
		Integer replyId = ViewPostsReplies.getReplyId();
		if (replyId == null) {
			ViewPostsReplies.setMessage("ReplyId must be a valid integer.");
			return;
		}

		String err = model.deleteReply(replyId);
		if (err.isEmpty()) ViewPostsReplies.setMessage("Reply deleted.");
		else ViewPostsReplies.setMessage(err);

		refreshLists();
	}

	/**********
	 * <p> Method: handleSearchReplies() </p>
	 *
	 * <p> Description: Handles the "Search Replies" button.  Searches all replies for the
	 * keyword and puts the results in the reply subset list.</p>
	 */
	protected static void handleSearchReplies() {
		String err = model.searchReplies(ViewPostsReplies.getReplySearchKeyword());
		if (err.isEmpty()) ViewPostsReplies.setMessage("Reply search completed.");
		else ViewPostsReplies.setMessage(err);

		refreshLists();
	}

	/**********
	 * <p> Method: handleFilterRepliesByPostId() </p>
	 *
	 * <p> Description: Handles the "Filter by PostId" button.  Filters the replies to show
	 * only those that belong to the specified post.</p>
	 */
	protected static void handleFilterRepliesByPostId() {
		Integer postId = ViewPostsReplies.getReplyPostId();
		if (postId == null) {
			ViewPostsReplies.setMessage("Reply postId must be a valid integer.");
			return;
		}

		model.filterRepliesByPostId(postId);
		ViewPostsReplies.setMessage("Replies filtered by postId.");
		refreshLists();
	}

	/**********
	 * <p> Method: handleClearReplySubset() </p>
	 *
	 * <p> Description: Handles the "Clear Reply Subset" button.  Clears the reply subset
	 * list.</p>
	 */
	protected static void handleClearReplySubset() {
		model.clearReplySubset();
		ViewPostsReplies.setMessage("Reply subset cleared.");
		refreshLists();
	}

	// -----------------------
	// Navigation
	// -----------------------

	/**********
	 * <p> Method: performReturn() </p>
	 *
	 * <p> Description: Returns the user to the Role1 (Student) Home Page.  Same navigation
	 * pattern as other pages in the application.</p>
	 */
	protected static void performReturn() {
		guiRole1.ViewRole1Home.displayRole1Home(ViewPostsReplies.theStage, 
				ViewPostsReplies.theUser);
	}

	/**********
	 * <p> Method: performLogout() </p>
	 *
	 * <p> Description: Logs out the current user and returns to the login page.</p>
	 */
	protected static void performLogout() {
		guiUserLogin.ViewUserLogin.displayUserLogin(ViewPostsReplies.theStage);
	}

	/**********
	 * <p> Method: performQuit() </p>
	 *
	 * <p> Description: Terminates the application.</p>
	 */
	protected static void performQuit() {
		System.exit(0);
	}

	// -----------------------
	// Refresh View Lists
	// -----------------------

	/**********
	 * <p> Method: refreshLists() </p>
	 *
	 * <p> Description: Updates all four ListViews on the View with the current data from
	 * the Model.  Called after every CRUD operation to keep the display in sync.</p>
	 */
	protected static void refreshLists() {
		ViewPostsReplies.setAllPosts(model.getAllPosts());
		ViewPostsReplies.setSubsetPosts(model.getSubsetPosts());

		ViewPostsReplies.setAllReplies(model.getAllReplies());
		ViewPostsReplies.setSubsetReplies(model.getSubsetReplies());
	}
}