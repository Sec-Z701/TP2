package guiPostsReplies;

import java.util.ArrayList;

import entityClasses.Post;
import entityClasses.Reply;
import store.PostStore;
import store.ReplyStore;

/*******
 * <p> Title: ModelPostsReplies Class </p>
 *
 * <p> Description: This is the Model component of the Model-View-Controller (MVC) pattern for
 * the Student Discussion page.  It holds a PostStore and a ReplyStore and provides methods for
 * CRUD (Create, Read, Update, Delete) and subset operations on posts and replies.</p>
 *
 * <p> This class uses a singleton so that posts and replies persist when the user navigates
 * away from the discussion page (e.g., to update account settings) and comes back.  Without
 * the singleton, all posts and replies would be lost each time the page is re-displayed.</p>
 *
 * <p> The PostStore reference is passed into the ReplyStore constructor so that when a reply
 * is created, the ReplyStore can check that the parent post actually exists.  This prevents
 * replies from being created for posts that do not exist.</p>
 *
 * <p> Copyright: Lynn Robert Carter © 2025 </p>
 *
 * @author Lynn Robert Carter
 *
 * @version 1.00	2025-03-15 Initial version for HW2
 * @version 2.00	2025-03-20 Refactored to singleton for TP2 integration
 */
public class ModelPostsReplies {

	// The PostStore holds all posts and the current subset of posts (e.g., search results).
	// These two lists satisfy the requirement: "a class that supports storing all current
	// posts as well as any subset of the posts."
	private PostStore postStore;

	// The ReplyStore holds all replies and the current subset of replies.
	// It needs a reference to the PostStore so it can check that a parent post exists
	// before allowing a reply to be created.
	private ReplyStore replyStore;

	// Singleton instance so data persists across page navigations
	private static ModelPostsReplies theModel;

	/*******
	 * <p> Method: ModelPostsReplies() </p>
	 *
	 * <p> Description: Private constructor.  Creates the PostStore and ReplyStore.
	 * Private because external code should use getInstance() instead.</p>
	 */
	private ModelPostsReplies() {
		postStore = new PostStore();
		replyStore = new ReplyStore(postStore);
	}

	/*******
	 * <p> Method: getInstance() </p>
	 *
	 * <p> Description: Returns the single shared instance of this Model, creating it on
	 * the first call.  This is the singleton pattern.</p>
	 *
	 * @return the singleton ModelPostsReplies instance
	 */
	public static ModelPostsReplies getInstance() {
		if (theModel == null) {
			theModel = new ModelPostsReplies();
		}
		return theModel;
	}

	// -----------------------
	// POST operations
	// -----------------------

	/*******
	 * <p> Method: createPost </p>
	 *
	 * <p> Description: Creates a new post.  Delegates to PostStore which validates the
	 * input using PostValidator before adding it.</p>
	 *
	 * @param author	the username of the post author
	 * @param thread	the discussion thread/category (defaults to "General" if blank)
	 * @param title		the post title (must be 5-80 characters)
	 * @param body		the post body (must be 1-2000 characters)
	 *
	 * @return empty string if successful, or an error message if validation fails
	 */
	public String createPost(String author, String thread, String title, String body) {
		return postStore.createPost(author, thread, title, body);
	}

	/*******
	 * <p> Method: updatePost </p>
	 *
	 * <p> Description: Updates an existing post identified by postId.  Same validation
	 * rules as createPost.</p>
	 *
	 * @param postId	the ID of the post to update
	 * @param author	the updated author username
	 * @param thread	the updated thread/category
	 * @param title		the updated title
	 * @param body		the updated body
	 *
	 * @return empty string if successful, or an error message
	 */
	public String updatePost(int postId, String author, String thread, String title, String body) {
		return postStore.updatePost(postId, author, thread, title, body);
	}

	/*******
	 * <p> Method: deletePost </p>
	 *
	 * <p> Description: Deletes a post identified by postId.  Requires confirmDelete to
	 * be true to prevent accidental deletion.</p>
	 *
	 * @param postId		the ID of the post to delete
	 * @param confirmDelete	must be true to actually delete
	 *
	 * @return empty string if successful, or an error message
	 */
	public String deletePost(int postId, boolean confirmDelete) {
		return postStore.deletePost(postId, confirmDelete);
	}

	/*******
	 * <p> Method: searchPosts </p>
	 *
	 * <p> Description: Searches all posts for the keyword in the title, body, and thread.
	 * Results are placed in the subset list.</p>
	 *
	 * @param keyword	the search term (case-insensitive)
	 *
	 * @return empty string if matches found, or an error message
	 */
	public String searchPosts(String keyword) {
		return postStore.searchPostsByKeyword(keyword);
	}

	/*******
	 * <p> Method: clearPostSubset </p>
	 *
	 * <p> Description: Clears the post subset list, resetting any search results.</p>
	 */
	public void clearPostSubset() {
		postStore.clearSubsetPosts();
	}

	/*******
	 * <p> Method: getAllPosts </p>
	 *
	 * <p> Description: Returns the complete list of all posts.</p>
	 *
	 * @return ArrayList of all Post objects
	 */
	public ArrayList<Post> getAllPosts() {
		return postStore.getAllPosts();
	}

	/*******
	 * <p> Method: getSubsetPosts </p>
	 *
	 * <p> Description: Returns the current subset of posts (search results).  The subset
	 * may be empty, may contain one element, or may be arbitrarily large.</p>
	 *
	 * @return ArrayList of Post objects in the current subset
	 */
	public ArrayList<Post> getSubsetPosts() {
		return postStore.getSubsetPosts();
	}

	// -----------------------
	// REPLY operations
	// -----------------------

	/*******
	 * <p> Method: createReply </p>
	 *
	 * <p> Description: Creates a new reply linked to the specified post.  The ReplyStore
	 * checks that the parent post exists before allowing creation.</p>
	 *
	 * @param postId	the ID of the parent post
	 * @param author	the username of the reply author
	 * @param body		the reply body (must be 1-2000 characters)
	 *
	 * @return empty string if successful, or an error message
	 */
	public String createReply(int postId, String author, String body) {
		return replyStore.createReply(postId, author, body);
	}

	/*******
	 * <p> Method: updateReply </p>
	 *
	 * <p> Description: Updates an existing reply identified by replyId.</p>
	 *
	 * @param replyId	the ID of the reply to update
	 * @param author	the updated author username
	 * @param body		the updated body
	 *
	 * @return empty string if successful, or an error message
	 */
	public String updateReply(int replyId, String author, String body) {
		return replyStore.updateReply(replyId, author, body);
	}

	/*******
	 * <p> Method: deleteReply </p>
	 *
	 * <p> Description: Deletes a reply identified by replyId.</p>
	 *
	 * @param replyId	the ID of the reply to delete
	 *
	 * @return empty string if successful, or an error message
	 */
	public String deleteReply(int replyId) {
		return replyStore.deleteReply(replyId);
	}

	/*******
	 * <p> Method: searchReplies </p>
	 *
	 * <p> Description: Searches all replies for the keyword in the body field.
	 * Results are placed in the reply subset list.</p>
	 *
	 * @param keyword	the search term (case-insensitive)
	 *
	 * @return empty string if matches found, or an error message
	 */
	public String searchReplies(String keyword) {
		return replyStore.searchRepliesByKeyword(keyword);
	}

	/*******
	 * <p> Method: filterRepliesByPostId </p>
	 *
	 * <p> Description: Filters replies to show only those belonging to the specified post.
	 * Results are placed in the reply subset list.</p>
	 *
	 * @param postId	the ID of the post to filter by
	 */
	public void filterRepliesByPostId(int postId) {
		replyStore.filterRepliesByPostId(postId);
	}

	/*******
	 * <p> Method: clearReplySubset </p>
	 *
	 * <p> Description: Clears the reply subset list, resetting any search or filter results.</p>
	 */
	public void clearReplySubset() {
		replyStore.clearSubsetReplies();
	}

	/*******
	 * <p> Method: getAllReplies </p>
	 *
	 * <p> Description: Returns the complete list of all replies.</p>
	 *
	 * @return ArrayList of all Reply objects
	 */
	public ArrayList<Reply> getAllReplies() {
		return replyStore.getAllReplies();
	}

	/*******
	 * <p> Method: getSubsetReplies </p>
	 *
	 * <p> Description: Returns the current subset of replies.  The subset may be empty,
	 * may contain one element, or may be arbitrarily large.</p>
	 *
	 * @return ArrayList of Reply objects in the current subset
	 */
	public ArrayList<Reply> getSubsetReplies() {
		return replyStore.getSubsetReplies();
	}

	/*******
	 * <p> Method: getRepliesForPost </p>
	 *
	 * <p> Description: Returns all replies that belong to the specified post.</p>
	 *
	 * @param postId	the ID of the parent post
	 *
	 * @return ArrayList of Reply objects linked to that post
	 */
	public ArrayList<Reply> getRepliesForPost(int postId) {
		return replyStore.getRepliesForPost(postId);
	}
}